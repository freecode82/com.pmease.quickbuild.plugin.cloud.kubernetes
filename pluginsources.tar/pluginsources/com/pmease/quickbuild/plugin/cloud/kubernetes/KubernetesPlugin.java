package com.pmease.quickbuild.plugin.cloud.kubernetes;

import com.pmease.quickbuild.pluginsupport.AbstractPlugin;

public class KubernetesPlugin extends AbstractPlugin {
  public Object[] getExtensions() {
    return new Object[] { new KubernetesNodeCloud() };
  }
  
  public Object[] getSettingIndependentExtensions() {
    return getExtensions();
  }
  
  public Class<?> getSettingClass() {
    return KubernetesSetting.class;
  }
}
