package com.pmease.quickbuild.plugin.cloud.kubernetes;

import com.pmease.quickbuild.annotation.Editable;
import com.pmease.quickbuild.annotation.ScriptApi;
import com.pmease.quickbuild.annotation.Scriptable;
import org.hibernate.validator.constraints.NotEmpty;

@ScriptApi("Global setting for Kubernetes")
public class KubernetesSetting {
  private String configFile;
  
  private String kubeCtlPath;
  
  @Editable(name = "Kubernetes Config File", order = 100, description = "Specify absolute path to Kubernetes config file. It is the same file used by kubectl to access the cluster")
  @Scriptable
  @NotEmpty
  public String getConfigFile() {
    return this.configFile;
  }
  
  public void setConfigFile(String configFile) {
    this.configFile = configFile;
  }
  
  @Editable(name = "Path to kubectl Utility", order = 200, description = "Specify absolute path to the kubectl utility, for instance: /usr/bin/kubectl<br>If left empty, QB will try to find the utility from system path")
  @Scriptable
  public String getKubeCtlPath() {
    return this.kubeCtlPath;
  }
  
  public void setKubeCtlPath(String kubeCtlPath) {
    this.kubeCtlPath = kubeCtlPath;
  }
}
