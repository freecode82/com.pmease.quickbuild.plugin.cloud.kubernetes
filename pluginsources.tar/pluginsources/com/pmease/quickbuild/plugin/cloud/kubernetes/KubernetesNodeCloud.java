package com.pmease.quickbuild.plugin.cloud.kubernetes;

import com.pmease.quickbuild.extensionpoint.NodeCloud;
import com.pmease.quickbuild.grid.cloud.NodeLauncher;

public class KubernetesNodeCloud extends NodeCloud {
  public static final String LAUNCH_DATA_ENV = "QuickBuildK8SLaunchData";
  
  public Class<? extends NodeLauncher> getNodeLauncherClass() {
    return (Class)KubernetesNodeLauncher.class;
  }
  
  public String getNodeLaunchData() {
    return System.getenv("QuickBuildK8SLaunchData");
  }
}
