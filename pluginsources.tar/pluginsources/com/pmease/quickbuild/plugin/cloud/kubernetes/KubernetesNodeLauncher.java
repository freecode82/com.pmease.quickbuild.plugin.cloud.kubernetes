package com.pmease.quickbuild.plugin.cloud.kubernetes;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.pmease.quickbuild.annotation.Editable;
import com.pmease.quickbuild.annotation.Multiline;
import com.pmease.quickbuild.annotation.Scriptable;
import com.pmease.quickbuild.execution.Commandline;
import com.pmease.quickbuild.execution.LineConsumer;
import com.pmease.quickbuild.grid.cloud.LaunchResult;
import com.pmease.quickbuild.grid.cloud.NodeLauncher;
import com.pmease.quickbuild.migration.VersionedDocument;
import com.pmease.quickbuild.pluginsupport.PluginSettingHelper;
import com.pmease.quickbuild.util.FileUtils;
import com.pmease.quickbuild.util.StringUtils;
import java.io.File;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Stack;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.Nullable;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

//@Editable(name = "Launch node into Kubernetes cluster", order = 500)
@Editable(name = "Launch node into Kubernetes cluster custom", order = 500)
public class KubernetesNodeLauncher extends NodeLauncher {
  private static final long serialVersionUID = 1L;
  
  private static final String DEFAULT_POD_CUSTOMIZATION = "apiVersion: v1\nkind: Pod\nmetadata:\n  name: ${name}\nspec:\n  containers:\n  - name: ${name}\n    imagePullPolicy: ${imagePullPolicy}\n#    resources:\n#      requests:\n#        cpu: 2000m\n#        memory: 8000m\n  nodeSelector:\n    kubernetes.io/os: linux\n  restartPolicy: Never";
  
  private static final Logger logger = LoggerFactory.getLogger(KubernetesNodeLauncher.class);
  
  private String configFile;
  
  private String agentNamespace = "buildagent";
  
  private String agentImage;
  
  private int agentPort = 8811;
  
  private boolean exposeServiceViaNodePort = false; //change true => false
  
  // add line change
  private boolean exposeServiceViaClusterIp = true;
  private String ingressCustomization;
  private int agentStartCnt;
  private int agentEndCnt;
  private String agentName = null;
  private String volumeName = null;
  // change end
  
  private String podCustomization = "apiVersion: v1\nkind: Pod\nmetadata:\n  name: ${name}\nspec:\n  containers:\n  - name: ${name}\n    imagePullPolicy: ${imagePullPolicy}\n#    resources:\n#      requests:\n#        cpu: 2000m\n#        memory: 8000m\n  nodeSelector:\n    kubernetes.io/os: linux\n  restartPolicy: Never";
  
  @Editable(name = "Kubernetes Config File", order = 50, description = "Optionally specify absolute path to Kubernetes config file to override the global config file setting")
  @Scriptable
  public String getConfigFile() {
    return this.configFile;
  }
  
  public void setConfigFile(String configFile) {
    this.configFile = configFile;
  }
  
  @Editable(order = 100, name = "Kubernetes Namespace", description = "QuickBuild will create pods and services in cluster to launch buid agents. This setting tells Kubernetes where to place those pods and services")
  @Scriptable
  @NotEmpty
  public String getAgentNamespace() {
    return this.agentNamespace;
  }
  
  public void setAgentNamespace(String agentNamespace) {
    this.agentNamespace = agentNamespace;
  }
  
  @Editable(order = 200, name = "Docker Image", description = "Specify docker image used to launch the build agent. Refer to <a href='$docroot/Launch+Node+in+Kubernetes#LaunchNodeinKubernetes-createbuildagentimage' target='_blank'>the document</a> on how to create your build agent image")
  @Scriptable
  @NotEmpty
  public String getAgentImage() {
    return this.agentImage;
  }
  
  public void setAgentImage(String agentImage) {
    this.agentImage = agentImage;
  }


  // add line change
  // agent name and cnt, volume name
  @Editable(order = 210, name = "Agent name", description = "A common name for the created pod")
  public String getAgentName() {
    return this.agentName;
  }
  
  public void setAgentName(String agentName) {
    this.agentName = agentName;
  }


  @Editable(order = 220, name = "Agent start Number", description = "Number to be added to the beginning of agent name")
  public int getAgentStartCnt() {
    return this.agentStartCnt;
  }
  
  public void setAgentStartCnt(int agentCnt) {
    this.agentStartCnt = agentCnt;
  }

  @Editable(order = 230, name = "Agent end Number", description = "Number to be added to the end of agent name")
  public int getAgentEndCnt() {
    return this.agentEndCnt;
  }

  public void setAgentEndCnt(int agentCnt) {
    this.agentEndCnt = agentCnt;
  }

  @Editable(order = 250, name = "Volume name", description = "Volume name to give to agent. use ${volumename} in spec.volumes.name")
  public String getVolumeName() {
    return this.volumeName;
  }

  public void setVolumeName(String volumeName) {
    this.volumeName = volumeName;
  }
  // end change
  
 
  @Editable(order = 300, name = "Agent Port", description = "Specify the port to be exposed by the docker container. It should be the same as the port defined in conf/node.properties in the build agent image")
  public int getAgentPort() {
    return this.agentPort;
  }
  
  public void setAgentPort(int agentPort) {
    this.agentPort = agentPort;
  }
  
  @Editable(order = 400, description = "Whether or not to expose build agent service via NodePort. Enable this if QuickBuild server can not access cluster ip of build agent pod")
  public boolean isExposeServiceViaNodePort() {
    return this.exposeServiceViaNodePort;
  }
  
  public void setExposeServiceViaNodePort(boolean exposeServiceViaNodePort) {
    this.exposeServiceViaNodePort = exposeServiceViaNodePort;
  }
  
  //add line change
  //clusterip create service(clusterip) and ingress
  @Editable(order = 450, description = "Whether or not to expose build agent service via ClusterIP. Enable this if QuickBuild server can not access cluster ip of build agent pod")
  public boolean isExposeServiceViaClusterIp() {
    return this.exposeServiceViaClusterIp;
  }
  
  public void setExposeServiceViaClusterIp(boolean exposeServiceViaClusterIp) {
    this.exposeServiceViaClusterIp = exposeServiceViaClusterIp;
  }

  @Editable(name = "Ingress", order = 460, description = "ingress yaml")
  @Multiline
  public String getIngressCustomization() {
    return this.ingressCustomization;
  }
  
  public void setIngressCustomization(String ingressCustomization) {
    this.ingressCustomization = ingressCustomization;
  }
  // add end

  @Editable(order = 500, description = "Optionally customize build agent pod spec via <a href='https://kubernetes.io/docs/tasks/manage-kubernetes-objects/kustomization/' target='_blank'>kustomization</a>.Placeholder ${name} will be replaced by pod/container name, and ${imagePullPolicy} will be replaced by appropriate image pull policy")
  @Multiline
  public String getPodCustomization() {
    return this.podCustomization;
  }
  
  public void setPodCustomization(String podCustomization) {
    this.podCustomization = podCustomization;
  }
  
  private String getEffectiveConfigFile() {
    if (getConfigFile() != null)
      return getConfigFile(); 
    return ((KubernetesSetting)PluginSettingHelper.getSetting(KubernetesPlugin.class, true)).getConfigFile();
  }
  
  private Commandline newKubeCtl() {
    KubernetesSetting setting = (KubernetesSetting)PluginSettingHelper.getSetting(KubernetesPlugin.class, true);
    String kubectl = setting.getKubeCtlPath();
    if (kubectl == null)
      kubectl = "kubectl"; 
    Commandline cmdline = new Commandline(kubectl);
    cmdline.addArgValue("--kubeconfig");
    cmdline.addArgValue(getEffectiveConfigFile());
    return cmdline;
  }
  
  private void createResource(Map<Object, Object> resourceDef, String customization) {
    Commandline kubectl = newKubeCtl();
    File tempDir = null;
    try {
      final AtomicReference<String> resourceNameRef = new AtomicReference<>(null);
      tempDir = FileUtils.createTempDir();
      String resourceYaml = (new Yaml()).dump(resourceDef);
      FileUtils.createDir(new File(tempDir, "base"));
      String kustomization = "namespace: " + getAgentNamespace() + "\nresources:\n- base.yaml\n";
      FileUtils.writeFile(new File(tempDir, "base/kustomization.yaml"), kustomization, StandardCharsets.UTF_8
          .name());
      FileUtils.writeFile(new File(tempDir, "base/base.yaml"), resourceYaml, StandardCharsets.UTF_8.name());
      FileUtils.createDir(new File(tempDir, "custom"));
      kustomization = "namespace: " + getAgentNamespace() + "\nbases:\n- ../base\npatchesStrategicMerge:\n- custom.yaml\n";
      FileUtils.writeFile(new File(tempDir, "custom/kustomization.yaml"), kustomization, StandardCharsets.UTF_8
          .name());
      FileUtils.writeFile(new File(tempDir, "custom/custom.yaml"), customization, StandardCharsets.UTF_8
          .name());
      kubectl.addArgLine("apply -k .");
      kubectl.execute(new File(tempDir, "custom"), (OutputStream)new LineConsumer() {
            public void consume(String line) {
              resourceNameRef.set(line);
            }
          },  new LineConsumer() {
            public void consume(String line) {
              if (line.startsWith("Warning: Autopilot set default resource requests")) {
                KubernetesNodeLauncher.logger.warn(line.substring("Warning: ".length()));
              } else {
                KubernetesNodeLauncher.logger.error(line);
              } 
            }
          }).checkReturnCode();
    } finally {
      if (tempDir != null)
        FileUtils.deleteDir(tempDir); 
    } 
  }
  
  // add chane line
  private void createResourceCustom(Map<Object, Object> resourceDef, String customization) {
    Commandline kubectl = newKubeCtl();
    File tempDir = null;
    try {
      final AtomicReference<String> resourceNameRef = new AtomicReference<>(null);
      tempDir = FileUtils.createTempDir();
      String resourceYaml = (new Yaml()).dump(resourceDef);
      FileUtils.createDir(new File(tempDir, "base"));
      String kustomization = "namespace: " + getAgentNamespace() + "\nresources:\n- base.yaml\n";
      FileUtils.writeFile(new File(tempDir, "base/kustomization.yaml"), kustomization, StandardCharsets.UTF_8
          .name());
      FileUtils.writeFile(new File(tempDir, "base/base.yaml"), resourceYaml, StandardCharsets.UTF_8.name());
      FileUtils.createDir(new File(tempDir, "custom"));
      kustomization = "namespace: " + getAgentNamespace() + "\nbases:\n- ../base\npatchesStrategicMerge:\n- custom.yaml\n";
      FileUtils.writeFile(new File(tempDir, "custom/kustomization.yaml"), kustomization, StandardCharsets.UTF_8
          .name());
      FileUtils.writeFile(new File(tempDir, "custom/custom.yaml"), customization, StandardCharsets.UTF_8
          .name());
      kubectl.addArgLine("create -f custom.yaml");
      kubectl.execute(new File(tempDir, "custom"), (OutputStream)new LineConsumer() {
            public void consume(String line) {
              resourceNameRef.set(line);
            }
          },  new LineConsumer() {
            public void consume(String line) {
              if (line.startsWith("Warning: Autopilot set default resource requests")) {
                KubernetesNodeLauncher.logger.warn(line.substring("Warning: ".length()));
              } else {
                KubernetesNodeLauncher.logger.error(line);
              }
            }
          }).checkReturnCode();
    } finally {
      if (tempDir != null)
        FileUtils.deleteDir(tempDir);
    }
  }
  // end line

  private void createNamespace(String namespace) {
    final AtomicBoolean namespaceExists = new AtomicBoolean(false);
    Commandline kubectl = newKubeCtl();
    kubectl.addArgLine("get namespaces --field-selector metadata.name=" + namespace + " -o name");
    kubectl.execute((OutputStream)new LineConsumer() {
          public void consume(String line) {
            namespaceExists.set(true);
          }
        },  new LineConsumer() {
          public void consume(String line) {
            KubernetesNodeLauncher.logger.error(line);
          }
        }).checkReturnCode();
    if (!namespaceExists.get()) {
      kubectl = newKubeCtl();
      kubectl.addArgLine("create namespace " + namespace);
      kubectl.execute((OutputStream)new LineConsumer() {
            public void consume(String line) {
              KubernetesNodeLauncher.logger.debug(line);
            }
          },  new LineConsumer() {
            public void consume(String line) {
              KubernetesNodeLauncher.logger.error(line);
            }
          }).checkReturnCode();
    } 
  }
  
  private <T> void initMap(Map<T, T> map, T... args) {
    Preconditions.checkArgument((args.length % 2 == 0), "Arguments should be key/value pairs");
    for (int i = 0; i < args.length / 2; i++)
      map.put(args[i * 2], args[i * 2 + 1]); 
  }
  
  private <T> Map<T, T> newLinkedHashMap(T... args) {
    Map<T, T> map = new LinkedHashMap<>();
    initMap(map, args);
    return map;
  }
  
  @Nullable
  private String getHostIP(String podName) {
    final AtomicReference<String> hostIP = new AtomicReference<>(null);
    Commandline kubectl = newKubeCtl();
    kubectl.addArgLine("get pod " + podName + " -o jsonpath={.status.hostIP} -n " + getAgentNamespace());
    kubectl.execute((OutputStream)new LineConsumer() {
          public void consume(String line) {
            if (StringUtils.isNotBlank(line))
              hostIP.set(line.trim()); 
          }
        },  new LineConsumer() {
          public void consume(String line) {
            KubernetesNodeLauncher.logger.error(line);
          }
        }).checkReturnCode();
    return hostIP.get();
  }
  
  private String getNodePort(String serviceName) {
    final AtomicReference<String> nodePort = new AtomicReference<>(null);
    Commandline kubectl = newKubeCtl();
    kubectl.addArgLine("get service " + serviceName + " -o \"jsonpath={range .spec.ports[*]}{.nodePort}{end}\" -n " + getAgentNamespace());
    kubectl.execute((OutputStream)new LineConsumer() {
          public void consume(String line) {
            if (StringUtils.isNotBlank(line))
              nodePort.set(line.trim()); 
          }
        },  new LineConsumer() {
          public void consume(String line) {
            KubernetesNodeLauncher.logger.error(line);
          }
        }).checkReturnCode();
    return nodePort.get();
  }
  
  //add line change
  //add function all getServicePort
  private String getServicePort(String serviceName) {
    final AtomicReference<String> servicePort = new AtomicReference<>(null);
    Commandline kubectl = newKubeCtl();
    kubectl.addArgLine("get service " + serviceName + " -o \"jsonpath={range .spec.ports[*]}{.port}{end}\" -n " + getAgentNamespace());
    kubectl.execute((OutputStream)new LineConsumer() {
          public void consume(String line) {
            if (StringUtils.isNotBlank(line))
              servicePort.set(line.trim()); 
          }
        },  new LineConsumer() {
          public void consume(String line) {
            KubernetesNodeLauncher.logger.error(line);
          }
        }).checkReturnCode();
    return servicePort.get();
  }

  private String getIngressPort(String serviceName) {
    final AtomicReference<String> ingressPort = new AtomicReference<>(null);
    Commandline kubectl = newKubeCtl();
    kubectl.addArgLine("get ingress " + serviceName + " -n " + getAgentNamespace());
    kubectl.execute((OutputStream)new LineConsumer() {
          public void consume(String line) {
            if (StringUtils.isNotBlank(line))
              ingressPort.set(String.valueOf(getAgentPort()));
          }
        },  new LineConsumer() {
          public void consume(String line) {
            KubernetesNodeLauncher.logger.error(line);
          }
        }).checkReturnCode();
    return ingressPort.get();
  }

  private boolean checkAgentName(String baseName, String namespace) {
    final AtomicBoolean podExists = new AtomicBoolean(false);
    Commandline kubectl = newKubeCtl();
    kubectl.addArgLine("get pods --field-selector metadata.name=" + baseName + " -n" + namespace + " -o name");
    kubectl.execute((OutputStream)new LineConsumer() {
          public void consume(String line) {
            podExists.set(true);
          }
        },  new LineConsumer() {
          public void consume(String line) {
            KubernetesNodeLauncher.logger.error(line);
          }
        }).checkReturnCode();

    return podExists.get();
  }
  //end change

  public LaunchResult launchNode(String launchData, boolean testLaunch) {
    //String agentName = "buildagent-" + UUID.randomUUID().toString();
    //add line change
    String agentName = "qbagent-";
    String volName = null;
    boolean okornot = true;
    //end change

    
    try {
      //add line change
      if (getAgentName() != null) {
        agentName = agentName + getAgentName();
        if (getVolumeName() == null){
          agentName = agentName + UUID.randomUUID().toString();
        } else {
          int startNum = getAgentStartCnt();
          int endNum = getAgentEndCnt();

          //if (startNum == null || endNum == null) {
          //  KubernetesNodeLauncher.logger.error("if exist volumeName, must fill agent start Number and agent end number");
          //  throw new InterruptedException("if exist volumeName, must fill agent start Number and agent end number");
          //}

          for (int i=startNum; i <= endNum; i++) {
            okornot = checkAgentName(agentName = agentName + "-" + i, getAgentNamespace());
            if (okornot == false) {
              volName = getVolumeName() + "-" + i;
              break;
            }
          }
          if (okornot == true) { // make node full startnum to endnum
            KubernetesNodeLauncher.logger.error("make full node. startnum to endnum");
            throw new InterruptedException("make full node. startnum to endnum");   
          }
        }
      } else {
        agentName = agentName + UUID.randomUUID().toString();
      }
      // end change

      createNamespace(getAgentNamespace());
      Map<Object, Object> containerSpec = newLinkedHashMap(new Object[] { "name", agentName, "image", 
            
            getAgentImage(), "ports", 
            Lists.newArrayList((Object[])new Map[] { newLinkedHashMap(new Serializable[] { "containerPort", Integer.valueOf(this.agentPort) }) }), "env", Lists.newArrayList((Object[])new Map[] { newLinkedHashMap(new String[] { "name", "QuickBuildK8SLaunchData", "value", launchData }) }) });
      Map<Object, Object> podSpec = newLinkedHashMap(new Object[] { "containers", 
            Lists.newArrayList((Object[])new Map[] { containerSpec }) });
      Map<Object, Object> podDef = newLinkedHashMap(new Object[] { "apiVersion", "v1", "kind", "Pod", "metadata", 

            
            newLinkedHashMap(new Object[] { "name", agentName, "labels", newLinkedHashMap(new String[] { "run", agentName }) }), "spec", podSpec });
      String imagePullPolicy = testLaunch ? "Always" : "IfNotPresent";
      String custom = getPodCustomization();
      if (custom != null) {
        custom = StringUtils.replace(custom, "${name}", agentName);
        custom = StringUtils.replace(custom, "${imagePullPolicy}", imagePullPolicy);
        //add line change
        if (volName != null) {
          custom = StringUtils.replace(custom, "${volumename}", volName);
        }
        // change end
      } else {
        custom = "apiVersion: v1\nkind: Pod\nmetadata:\n  name: " + agentName + "\n";
      } 
      createResource(podDef, custom);
      while (getHostIP(agentName) == null)
        Thread.sleep(1000L); 


      //add line change
      //make ingress code
      String ingressCustom = getIngressCustomization();
      if (ingressCustom != null) {
        
        ingressCustom = StringUtils.replace(ingressCustom, "${name}", agentName);

        Map<Object, Object> ingressServiceDef = newLinkedHashMap(new Object[] { "apiVersion", "v1", "kind", "Service", "metadata", 

              
              newLinkedHashMap(new Object[] { "name", agentName, "labels", newLinkedHashMap(new String[] { "run", agentName }) }), "spec", newLinkedHashMap(new Object[] { "type", "NodePort", "ports", Lists.newArrayList((Object[])new Map[] { newLinkedHashMap(new Serializable[] { "port", Integer.valueOf(this.agentPort), "targetPort", 
                          Integer.valueOf(this.agentPort) }) }), "selector", newLinkedHashMap(new String[] { "run", agentName }) }) });
        custom = "apiVersion: v1\nkind: Service\nmetadata:\n  name: " + agentName + "\n";
        createResourceCustom(ingressServiceDef, ingressCustom);
        String ingressPort;
        while ((ingressPort = getIngressPort(agentName)) == null)
          Thread.sleep(1000L); 
      } 
      //ingress end

      if (isExposeServiceViaNodePort()) {
        Map<Object, Object> serviceDef = newLinkedHashMap(new Object[] { "apiVersion", "v1", "kind", "Service", "metadata", 

              
              newLinkedHashMap(new Object[] { "name", agentName, "labels", newLinkedHashMap(new String[] { "run", agentName }) }), "spec", newLinkedHashMap(new Object[] { "type", "NodePort", "ports", Lists.newArrayList((Object[])new Map[] { newLinkedHashMap(new Serializable[] { "port", Integer.valueOf(this.agentPort), "targetPort", 
                          Integer.valueOf(this.agentPort) }) }), "selector", newLinkedHashMap(new String[] { "run", agentName }) }) });
        custom = "apiVersion: v1\nkind: Service\nmetadata:\n  name: " + agentName + "\n";
        createResource(serviceDef, custom);
        String nodePort;
        while ((nodePort = getNodePort(agentName)) == null)
          Thread.sleep(1000L); 
        return new LaunchResult(agentName, null, Integer.parseInt(nodePort), Boolean.valueOf(false));
      } 


      //add line change
      //new add 15 line
      if (isExposeServiceViaClusterIp()) {
        Map<Object, Object> serviceDef = newLinkedHashMap(new Object[] { "apiVersion", "v1", "kind", "Service", "metadata", 

              
              newLinkedHashMap(new Object[] { "name", agentName, "labels", newLinkedHashMap(new String[] { "run", agentName }) }), "spec", newLinkedHashMap(new Object[] { "type", "ClusterIP", "ports", Lists.newArrayList((Object[])new Map[] { newLinkedHashMap(new Serializable[] { "port", Integer.valueOf(this.agentPort), "targetPort", 
                          Integer.valueOf(this.agentPort) }) }), "selector", newLinkedHashMap(new String[] { "run", agentName }) }) });
        custom = "apiVersion: v1\nkind: Service\nmetadata:\n  name: " + agentName + "\n";
        createResource(serviceDef, custom);
        String servicePort;
        while ((servicePort = getServicePort(agentName)) == null)
          Thread.sleep(1000L); 
        return new LaunchResult(agentName, null, Integer.parseInt(servicePort), Boolean.valueOf(false));
      } 
      // add end

      return new LaunchResult(agentName, null, 0, Boolean.valueOf(false));
    } catch (InterruptedException e) {
      throw new RuntimeException(e);
    } 
  }
  
  public void terminateNode(String nodeInstanceId) {
    if (isExposeServiceViaNodePort()) {
      Commandline commandline = newKubeCtl();
      commandline.addArgLine("delete service " + nodeInstanceId + " -n " + getAgentNamespace());
      commandline.execute((OutputStream)new LineConsumer() {
            public void consume(String line) {
              KubernetesNodeLauncher.logger.debug(line);
            }
          },  new LineConsumer() {
            public void consume(String line) {
              KubernetesNodeLauncher.logger.error(line);
            }
          }).checkReturnCode();
    } 

    //add line change
    if (isExposeServiceViaClusterIp()) {
      Commandline commandline = newKubeCtl();
      commandline.addArgLine("delete service " + nodeInstanceId + " -n " + getAgentNamespace());
      commandline.execute((OutputStream)new LineConsumer() {
            public void consume(String line) {
              KubernetesNodeLauncher.logger.debug(line);
            }
          },  new LineConsumer() {
            public void consume(String line) {
              KubernetesNodeLauncher.logger.error(line);
            }
          }).checkReturnCode();
    }


    if (getIngressCustomization() != null) {
      Commandline commandline = newKubeCtl();
      commandline.addArgLine("delete ingress " + nodeInstanceId + " -n " + getAgentNamespace());
      commandline.execute((OutputStream)new LineConsumer() {
            public void consume(String line) {
              KubernetesNodeLauncher.logger.debug(line);
            }
          },  new LineConsumer() {
            public void consume(String line) {
              KubernetesNodeLauncher.logger.error(line);
            }
          }).checkReturnCode();
    } 
    // end change
 
    Commandline kubectl = newKubeCtl();
    kubectl.addArgLine("delete pod " + nodeInstanceId + " -n " + getAgentNamespace());
    kubectl.execute((OutputStream)new LineConsumer() {
          public void consume(String line) {
            KubernetesNodeLauncher.logger.debug(line);
          }
        },  new LineConsumer() {
          public void consume(String line) {
            KubernetesNodeLauncher.logger.error(line);
          }
        }).checkReturnCode();
  }
  
  public boolean isTerminated(String nodeInstanceId) {
    final AtomicBoolean notFound = new AtomicBoolean(false);
    Commandline kubectl = newKubeCtl();
    kubectl.addArgLine("get pod " + nodeInstanceId + " -n " + getAgentNamespace());
    Commandline.ExecuteResult result = kubectl.execute((OutputStream)new LineConsumer() {
          public void consume(String line) {}
        },  new LineConsumer() {
          public void consume(String line) {
            if (line.startsWith("Error from server (NotFound):")) {
              notFound.set(true);
            } else {
              KubernetesNodeLauncher.logger.error(line);
            } 
          }
        });
    if (notFound.get())
      return true; 
    result.checkReturnCode();
    return false;
  }
  
  public boolean shouldRetest(NodeLauncher beforeModification) {
    return !getAgentImage().equals(((KubernetesNodeLauncher)beforeModification).getAgentImage());
  }
  
  private void migrate1(VersionedDocument dom, Stack<Integer> versions) {
    dom.getRootElement().addElement("exposeServiceViaNodePort").setText("true");
  }
  
  private void migrate2(VersionedDocument dom, Stack<Integer> versions) {
    dom.getRootElement().addElement("podCustomization").setText("apiVersion: v1\nkind: Pod\nmetadata:\n  name: ${name}\nspec:\n  containers:\n  - name: ${name}\n    imagePullPolicy: ${imagePullPolicy}\n#    resources:\n#      requests:\n#        cpu: 2000m\n#        memory: 8000m\n  nodeSelector:\n    kubernetes.io/os: linux\n  restartPolicy: Never");
  }
}
